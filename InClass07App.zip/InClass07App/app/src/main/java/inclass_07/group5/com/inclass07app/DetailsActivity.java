package inclass_07.group5.com.inclass07app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DetailsActivity extends AppCompatActivity {
    ImageView imageView;
    String image;
    String formatDate;
    String reqdata,byname,image1,title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        setTitle("Details Activity");



        TextView storyTitle = (TextView) findViewById(R.id.textView_storytitle);
        TextView storyByLine = (TextView) findViewById(R.id.textView_storybyline);
        imageView = (ImageView) findViewById(R.id.imageView);
        TextView abstractContent = (TextView) findViewById(R.id.textView_abstract);

        if (getIntent().getExtras() != null){
            reqdata = getIntent().getExtras().getString(GetStoryAsyncTask.CLICKED_ABSTRACT);
            byname = getIntent().getExtras().getString(GetStoryAsyncTask.CLICKED_BYNAME);
            image1 = getIntent().getExtras().getString(GetStoryAsyncTask.CLICKED_IMAGE);
            title = getIntent().getExtras().getString(GetStoryAsyncTask.CLICKED_Title);
        }

        if(image!= null){
            new GetImage().execute(image1);
        } else {
            imageView.setImageResource(R.drawable.picture_not_yet_available);
        }

        storyTitle.setText(title);
        storyByLine.setText(byname);
        abstractContent.setText("Abstract:" + "\n" + reqdata);

    }


    //ASYNC task to get images
    class GetImage extends AsyncTask<String, Void, Bitmap> {
        Bitmap image = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            imageView.setImageBitmap(image);
        }

        @Override
        protected Bitmap doInBackground(String... urls) {
            InputStream inputStream = null;
            String urlDisplay = urls[0];
            try {
                inputStream = new java.net.URL(urlDisplay).openStream();
                image = BitmapFactory.decodeStream(inputStream);
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return image;
        }
    }
}