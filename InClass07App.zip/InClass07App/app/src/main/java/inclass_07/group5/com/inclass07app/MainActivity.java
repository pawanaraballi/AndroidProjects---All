package inclass_07.group5.com.inclass07app;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity implements AdapterView.OnItemSelectedListener {
    final static String NEWS_KEY = "NEWS";
    String newsCategories = "";
    Spinner newsSpinner;
    Button button_submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newsSpinner = (Spinner) findViewById(R.id.spinner);
        button_submit = (Button) findViewById(R.id.button_submit);

        ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.categories, android.R.layout.simple_spinner_item);
        newsSpinner.setAdapter(adapter);

        adapter.setNotifyOnChange(true);

        newsSpinner.setOnItemSelectedListener(this);

        button_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inte = new Intent(MainActivity.this, TopStories.class);
                inte.putExtra(NEWS_KEY, newsCategories);
                startActivity(inte);

                Log.d("demo", newsCategories);
            }
        });

    }

    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        // parent.getItemAtPosition(pos)
        TextView selectedText = (TextView) view;
        newsCategories = (String) selectedText.getText();

    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }
}